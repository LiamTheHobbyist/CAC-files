THANK YOU FOR DOWNLODING THE CAC it took so mutch work to get right and i hope you get good use out of it :)



files to make the CAC

SOFTWARE joytokey (just look it up) a slicer of your choice

PARTS LIST all the 3d printed parts and this hardware 25$ https://www.amazon.com/Buttons-EG-STARTS-Joystick-Raspberry/dp/B01M2X88QP/ref=sr_1_7?crid=3LJ6ZNSBIR75D&keywords=arcade+buttons&qid=1701916898&sprefix=arcade+bu%2Caps%2C191&sr=8-7 super glue (any brand will do) rough sand paper (only needed if mounting the joystic permently but good to have for the case) painters tape (only needed for the not perment solution) zip ties (optinal for wiring)

HOW TO MAKE IT

print out all the files place the top down (the one with the 6 holes or the one with the one smaller hole) for improved surfuce finish

once you are done with that start with glueing the 2 main body pices and the 2 lid pices of the base APART FROM EACH OTHER and i would recomend useing popsical stics on the connecting sides to inprove strenth and also make shure you put the usb wire in to the ole as you close it cause it wont go trough after closing

once you connect both the bottom and the top we can start putting in the hardware

MOUTING THE JOYSTICK

there are 2 ways of doing it one is PERMANENT and the other is not so if you want to use the parts again use the 2nd one

1ST PERMANENT sand the metal of the joystick without the ball and you dont need to sand too much (I would plug it in to the board and plug it in to your pc make shure its the right way up the 2 big holes should be facing you use joy to key to do this) then stick it on use activator if you want make shure is lined up horozoly wait for glue to fully dry then continue to button placement

2ND not permenent put painters tape on the joystick were you want to glue (I would plug it in to the board and plug it in to your pc make shure its the right way up the 2 big holes should be facing you use joy to key to do this) then stick it on use activator if you want make shure is lined up horozoly wait for glue to fully dry then continue to button placement

BUTTON PLACEMENT, WIRING, AND FINISHING

start by screwing in all the buttons useing the included washers useing whatever colors you want and then insert all of the wires in to the buttons ports (optinal ziptie the 6 main button wires togethor and the pinball buttons togethor and also the start and player one buttons together) now plug everything into the board then plug in the board plug it in to the PC then test on joy to key if all the buttons work then you can close it up with super glue with the bottom lid that you glued.

and your done use joy to key to set keybord contolls to each of the movements and have fun playing games on your new device

watermark shit plz ignor

This project was fully dsigned by Liam Earnest I dont allow anyone to sell my design for money or the finished project without my promission if you want to contact me do it through LiamTheHobbiest@gmail.com